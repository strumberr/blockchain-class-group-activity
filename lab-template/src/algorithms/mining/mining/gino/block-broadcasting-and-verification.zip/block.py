from dataclasses import dataclass
from hashlib import sha256
import json
import time
import asyncio
from ipv8.messaging.payload_dataclass import overwrite_dataclass
from merkle_tree import MerkleTree

# Custom dataclass implementation
dataclass = overwrite_dataclass(dataclass)

@dataclass(msg_id=3)  # Add a unique msg_id here
class BlockMessage:
    """ Represents a block message. """
    timestamp: int
    difficulty: int
    nonce: int
    prev_hash: str
    merkle_root: str
    coinbase_tx: str
    block_hash: str

@dataclass
class Transaction:
    """ Represents a basic transaction. """
    sender: str
    receiver: str
    amount: int
    nonce: int = 1
    ts: int = 0

@dataclass
class SignedTransaction:
    """ Represents a signed transaction including a signature and public key. """
    transaction: Transaction
    signature: str
    public_key: str

class Block:
    """ Represents a block of transactions. """
    def __init__(self, timestamp, difficulty, nonce, prev_hash, merkle_root, coinbase_tx):
        self.timestamp = timestamp
        self.difficulty = '0' * difficulty
        self.nonce = nonce
        self.prev_hash = prev_hash
        self.merkle_root = merkle_root
        self.coinbase_tx = coinbase_tx
        self.hash = self.calculate_hash()
    
    def calculate_hash(self):
        block_string = f'{self.timestamp}{self.difficulty}{self.nonce}{self.prev_hash}{self.merkle_root}{self.coinbase_tx}'
        return sha256(block_string.encode()).hexdigest()

class Blockchain:
    """ Manages the blockchain and its operations. """
    def __init__(self, node_id, difficulty_target):
        self.node_id = node_id
        self.difficulty_target = difficulty_target
        self.chain = [self.create_genesis_block()]
        self.active_mining = False
        self.community = None  # Will be set by ValidatorCommunity

    def create_merkle_root(self, transactions):
        """ Create a Merkle root from a list of signed transactions. """
        tree = MerkleTree()
        for signed_tx in transactions:
            tx_string = json.dumps(signed_tx.__dict__, default=lambda o: o.__dict__)
            tree.add_leaf(tx_string)
        return tree.get_root()

    def create_genesis_block(self):
        timestamp = int(time.time())
        difficulty = self.difficulty_target
        nonce = 0
        prev_hash = '0' * 64
        coinbase_tx = SignedTransaction(
            transaction=Transaction(sender="boss", receiver="0", amount=50, nonce=1, ts=timestamp),
            signature="coinbase_signature",
            public_key="coinbase_public_key"
        )
        transactions = [coinbase_tx]
        merkle_root = self.create_merkle_root(transactions)
        return Block(timestamp, difficulty, nonce, prev_hash, merkle_root, json.dumps(coinbase_tx.__dict__, default=lambda o: o.__dict__))

    async def create_new_block(self, transactions):
        timestamp = int(time.time())
        nonce = 0
        prev_hash = self.chain[-1].hash
        merkle_root = self.create_merkle_root(transactions)
        
        # Convert transactions to a JSON serializable format
        transactions_json = [tx.__dict__ for tx in transactions]
        
        new_block = Block(timestamp, self.difficulty_target, nonce, prev_hash, merkle_root, json.dumps(transactions_json))
        
        await self.mine_block(new_block)
        return new_block

    async def add_block(self, transactions):
        if len(transactions) % 3 != 0:
            raise ValueError("The number of transactions must be a multiple of 3.")
        
        for i in range(0, len(transactions), 3):
            batch = transactions[i:i+3]
            new_block = await self.create_new_block(batch)
            self.chain.append(new_block)
        return new_block
    
    def compute_hash(self, block, nonce):
        block_string = f'{block.timestamp}{block.difficulty}{nonce}{block.prev_hash}{block.merkle_root}{block.coinbase_tx}'
        return sha256(block_string.encode()).hexdigest()

    async def mine_block(self, block):
        print(f"Starting mining block {block}")
        
        # Start a timer
        start_time = time.time()
        start_time2 = time.time()
        hashes_computed = 0
        current_nonce = 0
        
        target = '0' * self.difficulty_target
        
        while True:
            self.active_mining = True
            
            # Every 2 seconds, print the time elapsed and the number of hashes computed
            if time.time() - start_time > 2:
                print(f"Hashes computed: {hashes_computed}")
                print(f"Time elapsed: {time.time() - start_time2:.2f} seconds")
                start_time = time.time()
                
            hash_result = self.compute_hash(block, current_nonce)
            
            if hash_result.startswith(target):
                block.nonce = current_nonce
                block.hash = hash_result
                print(f"Block mined by miner {self.node_id} with hash {block.hash}")
                
                # Add the block to the chain
                self.chain.append(block)
                
                # Broadcast the block to peers
                await self.community.broadcast_block(block)
                
                self.active_mining = False
                return
            
            current_nonce += 1
            hashes_computed += 1
            await asyncio.sleep(0)
